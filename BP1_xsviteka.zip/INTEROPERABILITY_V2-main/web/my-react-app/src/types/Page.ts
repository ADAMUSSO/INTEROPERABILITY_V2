export type Page = 'transfer' | 'balance' | 'wrap' | 'docs';
