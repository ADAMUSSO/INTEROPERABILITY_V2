export type Env = 'paseo_sepolia' | 'westend_sepolia' | 'polkadot_mainnet';
export type WalletKind = 'metamask' | 'talisman';